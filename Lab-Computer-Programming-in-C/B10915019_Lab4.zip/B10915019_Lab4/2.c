#include <stdio.h>

int main(){
    int c ;
    scanf("%d",&c);
    for(int i=0;i<c;i++)printf("%s","*");
    printf("\n");
}